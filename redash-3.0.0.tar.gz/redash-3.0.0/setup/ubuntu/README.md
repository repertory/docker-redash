Bootstrap scripts for Ubuntu 16.04.
