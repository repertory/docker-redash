# DEPRECATED 
(left for reference purposes only)

Bootstrap script for Amazon Linux AMI. *Not supported*, we recommend to use the Docker images instead.
