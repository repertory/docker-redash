from redash.models import ApiKey


if __name__ == '__main__':
    ApiKey.create_table()
